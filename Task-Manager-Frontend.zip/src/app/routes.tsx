import { BrowserRouter, Navigate, Route, Routes } from "react-router";
import type { ReactNode } from "react";
import DashboardPage from "../modules/Admin/pages/DashboardPage";
import CreateTaskPage from "../modules/Tasks/pages/CreateTaskPage";
import TaskDetailsPage from "../modules/Tasks/pages/TaskDetailsPage";
import UpdateTaskPage from "../modules/Tasks/pages/UpdateTaskPage";
import LoginPage from "../modules/auth/pages/LoginPage";
import SigninPage from "../modules/auth/pages/SigninPage";
import ManageTasksPage from "../modules/ManageTasks/pages/ManageTasksPage";
import TeamMemebersPage from "../modules/Users/pages/TeamMembersPage";
import EditUserPage from "../modules/Users/pages/EditUserPage";
import { useAuthStore } from "../modules/auth/state/auth.store";

function ProtectedRoute({ children }: { children: ReactNode }) {
  const accessToken = useAuthStore((state) => state.accessToken);
  const isHydrating = useAuthStore((state) => state.isHydrating);

  if (isHydrating) {
    return <div className="m-8">Loading session...</div>;
  }

  if (!accessToken) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
}

function RootRoute() {
  const accessToken = useAuthStore((state) => state.accessToken);
  const isHydrating = useAuthStore((state) => state.isHydrating);

  if (isHydrating) {
    return <div className="m-8">Loading session...</div>;
  }

  return <Navigate to={accessToken ? "/home" : "/login"} replace />;
}

function AdminRoute({ children }: { children: ReactNode }) {
  const accessToken = useAuthStore((state) => state.accessToken);
  const isHydrating = useAuthStore((state) => state.isHydrating);
  const role = useAuthStore((state) => state.user?.role?.toLowerCase());

  if (isHydrating) {
    return <div className="m-8">Loading session...</div>;
  }

  if (!accessToken) {
    return <Navigate to="/login" replace />;
  }

  if (role !== "admin") {
    return <Navigate to="/tasks" replace />;
  }

  return <>{children}</>;
}

export function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<RootRoute />} />
        <Route
          path="/home"
          element={
            <ProtectedRoute>
              <DashboardPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/tasks"
          element={
            <ProtectedRoute>
              <ManageTasksPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/tasks/:taskId"
          element={
            <ProtectedRoute>
              <TaskDetailsPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/tasks/create"
          element={
            <AdminRoute>
              <CreateTaskPage />
            </AdminRoute>
          }
        />
        <Route
          path="/tasks/:taskId/edit"
          element={
            <AdminRoute>
              <UpdateTaskPage />
            </AdminRoute>
          }
        />
        <Route
          path="/team-members"
          element={
            <AdminRoute>
              <TeamMemebersPage />  
            </AdminRoute>
          }
        />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SigninPage />} />
        <Route
          path="/user/settings"
          element={
            <ProtectedRoute>
              <EditUserPage />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
