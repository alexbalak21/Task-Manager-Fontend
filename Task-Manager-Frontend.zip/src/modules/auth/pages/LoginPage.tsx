import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate } from "react-router";
import loginSidePanel from "../../../assets/images/login_side_panel.jpg";
import Eye from "../../../assets/icons/Eye";
import EyeCorssed from "../../../assets/icons/Eye_corssed";
import { useAuthStore } from "../state/auth.store";
import { useToast } from "../../../components/ui/ToastProvider";

export default function LoginPage() {
  const navigate = useNavigate();
  const login = useAuthStore((state) => state.login);
  const accessToken = useAuthStore((state) => state.accessToken);
  const toast = useToast();

  const [email, setEmail] = useState("john.doe@example.com");
  const [password, setPassword] = useState("password@1234");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (accessToken) {
    return <Navigate to="/home" replace />;
  }

  const onSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setIsSubmitting(true);
    try {
      await login(email, password);
      toast.success("Login successful", "Welcome back.");
      navigate("/home", { replace: true });
    } catch {
      setError("Login failed. Check your credentials.");  
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#f3f3f5] lg:grid lg:grid-cols-[58%_42%]">
      <section className="flex min-h-screen flex-col px-6 py-8 sm:px-10 lg:px-14 lg:py-10">
        <p className="text-3xl font-semibold tracking-tight text-[#141414]">Task Manager</p>

        <div className="flex flex-1 items-center">
          <div className="mx-auto w-full max-w-155">
            <h1 className="text-center text-5xl font-semibold tracking-tight text-[#191919]">Welcome Back</h1>
            <p className="mt-4 text-center text-xl leading-tight text-[#333333]">
              Please enter your details to log in
            </p>

            <form onSubmit={onSubmit} className="mt-10 grid gap-5">
              <div>
                <label htmlFor="email" className="mb-2 block text-xl font-medium text-gray-700">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  required
                  className="h-13 w-full rounded-lg border border-[#e8e8ec] bg-[#f5f5f7] px-4 text-lg text-[#191919] placeholder:text-[#999] focus:border-[#2767e7] focus:outline-none"
                />
              </div>

              <div>
                <label htmlFor="password" className="mb-2 block text-xl font-medium text-gray-700">
                  Password
                </label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Min 8 Characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                    required
                    minLength={8}
                    className="h-13 w-full rounded-lg border border-[#e8e8ec] bg-[#f5f5f7] px-4 pr-12 text-lg text-[#191919] placeholder:text-[#999] focus:border-[#2767e7] focus:outline-none"
                  />
                  <button
                    type="button"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    onClick={() => setShowPassword((prev) => !prev)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 transition-colors hover:text-gray-600"
                  >
                    {showPassword ? <EyeCorssed className="h-6 w-6" /> : <Eye className="h-6 w-6" />}
                  </button>
                </div>
              </div>

              {error ? <p className="text-center text-md text-red-600">{error}</p> : null}

              <button
                type="submit"
                disabled={isSubmitting}
                className="mt-1 h-13 w-full rounded-lg bg-primary-500 text-xl font-semibold uppercase tracking-wide text-white transition-colors hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isSubmitting ? "Logging in..." : "Login"}
              </button>
            </form>

            <p className="mt-5 text-xl text-[#303030]">
              Don&apos;t have an account?{" "}
              <Link to="/signup" className="font-semibold text-primary-500 underline-offset-2 hover:underline">
                SignUp
              </Link>
            </p>
          </div>
        </div>
      </section>

      <aside className="relative hidden min-h-screen overflow-hidden lg:block">
        <img
          src={loginSidePanel}
          alt="Task collaboration panel"
          className="absolute inset-0 h-full w-full object-cover"
        />
      </aside>
    </main>
  );
}
