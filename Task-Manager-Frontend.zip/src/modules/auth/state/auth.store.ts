import { create } from "zustand";
import { AuthAPI } from "../services/auth.api";

type AuthUser = {
  id: number;
  name: string;
  email: string;
  role?: string;
  profileImage?: string | null;

};

type AuthResponseUser = AuthUser & {
  profile_image?: string;
};

const extractUser = (payload: unknown): AuthResponseUser | null => {
  if (!payload || typeof payload !== "object") {
    return null;
  }

  const candidate = payload as { user?: AuthResponseUser };
  return candidate.user ?? (payload as AuthResponseUser);
};

const normalizeUser = (user: AuthResponseUser | null | undefined): AuthUser | null => {
  if (!user) {
    return null;
  }

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    profileImage: user.profileImage ?? user.profile_image,
  };
};

interface AuthState {
  user: AuthUser | null;
  accessToken: string | null;
  refreshToken: string | null;
  isHydrating: boolean;
  setUser: (user: AuthUser | null) => void;

  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  refresh: () => Promise<void>;
  hydrate: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  // Start in hydrating mode when a refresh token exists so protected routes do not redirect early.
  user: null,
  accessToken: null,
  refreshToken: localStorage.getItem("refresh_token"),
  isHydrating: Boolean(localStorage.getItem("refresh_token")),
	setUser: (user) => set({ user }),

  login: async (email, password) => {
    const res = await AuthAPI.login(email, password);
    const user = extractUser(res.data);

    set({
      user: normalizeUser(user),
      accessToken: res.data.access_token,
      refreshToken: res.data.refresh_token,
    });

    localStorage.setItem("refresh_token", res.data.refresh_token);
  },

  register: async (name, email, password) => {
    const res = await AuthAPI.register(name, email, password);
    const user = extractUser(res.data);

    set({
      user: normalizeUser(user),
      accessToken: res.data.access_token,
      refreshToken: res.data.refresh_token,
    });

    localStorage.setItem("refresh_token", res.data.refresh_token);
  },

  refresh: async () => {
    const refreshToken = get().refreshToken;
    if (!refreshToken) {
      throw new Error("Missing refresh token");
    }

    const res = await AuthAPI.refresh(refreshToken);

    set({
      accessToken: res.data.access_token,
      refreshToken: res.data.refresh_token,
    });

    if (res.data.refresh_token) {
      localStorage.setItem("refresh_token", res.data.refresh_token);
    }

    const userResponse = await AuthAPI.me();
    set({ user: normalizeUser(extractUser(userResponse.data)) });
  },

  logout: () => {
    const hasAccessToken = Boolean(get().accessToken);
    if (hasAccessToken) {
      AuthAPI.logout().catch(() => undefined);
    }
    set({ user: null, accessToken: null, refreshToken: null });
    localStorage.removeItem("refresh_token");
  },

  hydrate: async () => {
    set({ isHydrating: true });
    try {
      if (get().refreshToken) {
        await get().refresh();
      }
    } catch {
      set({ user: null, accessToken: null, refreshToken: null });
      localStorage.removeItem("refresh_token");
    } finally {
      set({ isHydrating: false });
    }
  },
}));
